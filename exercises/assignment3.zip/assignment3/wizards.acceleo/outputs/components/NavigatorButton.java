package components;


import javax.swing.*;

// import components.*;

public class NavigatorButton extends JButton {

	private static final long serialVersionUID = 1L;

	public NavigatorButton(String label) {
		super(label);
	}

}