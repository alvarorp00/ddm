package components;

import javax.swing.JButton;

public class ReturnButton extends JButton {

	private static final long serialVersionUID = 1L;

	public ReturnButton(String label) {
		super(label);
	}

}