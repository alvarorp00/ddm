/**
 */
package wizards;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Close Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see wizards.WizardsPackage#getCloseButton()
 * @model
 * @generated
 */
public interface CloseButton extends Button {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void action();

} // CloseButton
